# SUNUSI iOS 27 — Android Launcher Project

Wannan shi ne farkon cikakken native Android launcher project. An tsara shi don Android 11 da wayoyi masu 4GB RAM.

## Abubuwan da ke aiki
- Yana bayyana a matsayin Home/Launcher app.
- Yana nuna apps da aka girka a waya.
- Ana iya bincika apps.
- App icons suna buɗe apps.
- Clock da date.
- Dock mai Phone, Messages, Camera da Settings.
- Control panel yana buɗe ainihin Android settings pages.
- Ba ya buƙatar account ko internet.

## Muhimmin bayani
Wannan SOURCE PROJECT ne, ba APK da aka riga aka compile ba. Ba a gina APK a nan ba. Don samar da APK, buɗe project ɗin a Android Studio ko AndroidIDE mai goyon bayan Gradle, sannan ka yi Build APK.

## Gina APK
1. Buɗe AndroidIDE ko Android Studio.
2. Zaɓi Open Project, ka buɗe folder `SUNUSI_iOS_27`.
3. Jira Gradle Sync ya gama.
4. Zaɓi Build > Build APK(s).
5. Ka girka APK ɗin da aka samar.
6. Danna Home, zaɓi SUNUSI iOS 27, sannan ka zaɓi Always domin ya zama default launcher.

## Iyakoki
- Android ne ke sarrafa Wi-Fi, Bluetooth, notifications da lock screen. Launcher ba zai iya canza dukkan waɗannan kai tsaye ba tare da izinin tsarin ba.
- Wannan sigar farko ce; ana iya ƙara widgets, notification panel na cikin app, wallpapers da ƙarin gyare-gyare a gaba.
