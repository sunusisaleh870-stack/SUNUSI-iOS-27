package com.sunusi.ios27;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.text.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, appGrid;
    EditText search;
    TextView clock, date;
    ArrayList<ResolveInfo> apps = new ArrayList<>();
    boolean drawerOpen = false;

    int white = Color.WHITE;
    int muted = 0xFFB8C8DC;
    int cyan = 0xFF63DFFF;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF07111F);
        getWindow().setNavigationBarColor(0xFF07111F);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildHome();
    }

    GradientDrawable shape(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        if (stroke != 0) d.setStroke(2, stroke);
        return d;
    }

    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    void buildHome() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 24, 20, 18);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF071321,0xFF102B48,0xFF080E1B}));
        setContentView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("SUNUSI", 14, cyan, true);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(brand, new LinearLayout.LayoutParams(0, 42, 1));
        TextView menu = text("◉  CONTROL", 12, white, true);
        menu.setPadding(14,10,14,10);
        menu.setBackground(shape(0x3324BCEB, 0x6659D9FF, 40));
        menu.setOnClickListener(v -> showControlPanel());
        top.addView(menu);
        root.addView(top);

        clock = text("", 54, white, false);
        clock.setGravity(Gravity.CENTER);
        clock.setPadding(0, 24, 0, 0);
        root.addView(clock);
        date = text(new java.text.SimpleDateFormat("EEEE, dd MMMM", Locale.getDefault()).format(new Date()), 14, muted, false);
        root.addView(date);
        updateClock();
        new Handler().postDelayed(new Runnable(){ public void run(){ updateClock(); new Handler().postDelayed(this,1000); }},1000);

        TextView greeting = text("LIQUID GLASS  •  FUTURE UI", 11, cyan, true);
        greeting.setPadding(0,22,0,14);
        root.addView(greeting);

        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextColor(white);
        search.setHintTextColor(muted);
        search.setHint("⌕   Search your apps");
        search.setTextSize(14);
        search.setPadding(18, 5, 18, 5);
        search.setBackground(shape(0x332C5575, 0x554FD8FF, 50));
        root.addView(search, new LinearLayout.LayoutParams(-1, 48));

        TextView heading = text("YOUR APPS", 12, muted, true);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        heading.setPadding(4,20,0,10);
        root.addView(heading);

        ScrollView scroll = new ScrollView(this);
        appGrid = new LinearLayout(this);
        appGrid.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(appGrid);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        loadApps("");
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){ loadApps(s.toString()); }
            public void afterTextChanged(Editable e){}
        });

        LinearLayout dock = new LinearLayout(this);
        dock.setGravity(Gravity.CENTER);
        dock.setPadding(8,10,8,10);
        dock.setBackground(shape(0x553A6687, 0x665CDFFF, 34));
        String[] labels = {"PHONE","MESSAGES","CAMERA","SETTINGS"};
        String[] symbols = {"☎","✉","◉","⚙"};
        for(int i=0;i<labels.length;i++){
            final int n=i;
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            TextView icon = text(symbols[i],23,white,true);
            item.addView(icon);
            TextView label = text(labels[i],8,muted,true);
            item.addView(label);
            item.setOnClickListener(v -> openNamed(labels[n]));
            dock.addView(item,new LinearLayout.LayoutParams(0,58,1));
        }
        root.addView(dock);
        TextView footer = text("Designed for your Android • SUNUSI iOS 27", 9, 0xFF8198B2, false);
        footer.setPadding(0,10,0,0);
        root.addView(footer);
    }

    void updateClock() {
        if(clock != null) clock.setText(new java.text.SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()));
    }

    void loadApps(String query) {
        if(appGrid == null) return;
        appGrid.removeAllViews();
        PackageManager pm = getPackageManager();
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(intent,0);
        Collections.sort(list,(a,b)->a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString()));
        ArrayList<ResolveInfo> filtered = new ArrayList<>();
        for(ResolveInfo r:list) if(r.loadLabel(pm).toString().toLowerCase().contains(query.toLowerCase())) filtered.add(r);
        apps = filtered;
        for(int start=0;start<filtered.size();start+=4) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER);
            for(int j=start;j<Math.min(start+4,filtered.size());j++) {
                ResolveInfo r=filtered.get(j);
                LinearLayout cell = new LinearLayout(this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER);
                cell.setPadding(3,9,3,12);
                ImageView iv = new ImageView(this);
                try { iv.setImageDrawable(r.loadIcon(pm)); } catch(Exception e){}
                cell.addView(iv,new LinearLayout.LayoutParams(48,48));
                TextView name=text(r.loadLabel(pm).toString(),10,white,false);
                name.setMaxLines(1);
                cell.addView(name);
                cell.setOnClickListener(v -> {
                    try { startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                            .setClassName(r.activityInfo.packageName,r.activityInfo.name)); }
                    catch(Exception e){ Toast.makeText(this,"Unable to open app",Toast.LENGTH_SHORT).show(); }
                });
                row.addView(cell,new LinearLayout.LayoutParams(0,92,1));
            }
            for(int k=filtered.size()-start;k<4;k++) row.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));
            appGrid.addView(row);
        }
        if(filtered.isEmpty()) {
            TextView empty=text("No matching apps",13,muted,false);
            appGrid.addView(empty);
        }
    }

    void openNamed(String name) {
        String action = name.equals("PHONE") ? Intent.ACTION_DIAL :
                name.equals("MESSAGES") ? Intent.ACTION_MAIN :
                name.equals("CAMERA") ? "android.media.action.IMAGE_CAPTURE" : null;
        try {
            if(name.equals("SETTINGS")) startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));
            else if(name.equals("MESSAGES")) {
                Intent i=new Intent(Intent.ACTION_MAIN); i.addCategory(Intent.CATEGORY_APP_MESSAGING); startActivity(i);
            } else startActivity(new Intent(action));
        } catch(Exception e) { Toast.makeText(this,"App not available",Toast.LENGTH_SHORT).show(); }
    }

    void showControlPanel() {
        String[] choices={"Wi-Fi settings","Bluetooth settings","Display settings","Sound settings","Battery settings","System settings"};
        new AlertDialog.Builder(this).setTitle("LIQUID CONTROL CENTER")
            .setItems(choices,(d,w)->{
                Intent i;
                switch(w){
                    case 0:i=new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS);break;
                    case 1:i=new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS);break;
                    case 2:i=new Intent(android.provider.Settings.ACTION_DISPLAY_SETTINGS);break;
                    case 3:i=new Intent(android.provider.Settings.ACTION_SOUND_SETTINGS);break;
                    case 4:i=new Intent(android.provider.Settings.ACTION_BATTERY_SAVER_SETTINGS);break;
                    default:i=new Intent(android.provider.Settings.ACTION_SETTINGS);
                }
                try{startActivity(i);}catch(Exception e){}
            }).setNegativeButton("Close",null).show();
    }
}
