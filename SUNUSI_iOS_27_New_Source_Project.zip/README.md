# SUNUSI iOS 27 Launcher

A fresh, lightweight native Android home-screen launcher starter project.

## Build using GitHub and Codemagic
1. Extract this ZIP.
2. Upload **all files and folders inside it** to the root of a new GitHub repository.
3. Add that repository in Codemagic.
4. Start the workflow configured by `codemagic.yaml`.
5. Download `app-debug.apk` from the build Artifacts.

## Set as the default launcher
Install the APK. Press Home and choose **SUNUSI iOS 27** as the Home app. Android may also let you choose it under Settings > Apps > Default apps > Home app.

Minimum Android: 6.0 (API 23). Target Android: 15 (API 35). No third-party libraries are required.
