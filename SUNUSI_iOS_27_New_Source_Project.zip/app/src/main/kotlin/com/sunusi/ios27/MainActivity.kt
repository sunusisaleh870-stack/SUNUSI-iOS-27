package com.sunusi.ios27

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private fun panel(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius
    }
    private fun label(value: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color); gravity = Gravity.CENTER
            if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            setPadding(6, 6, 6, 6)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(23, 32, 55)
        window.navigationBarColor = Color.rgb(13, 19, 34)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 22, 20, 16)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(52, 82, 137), Color.rgb(20, 29, 50), Color.rgb(12, 18, 32)))
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(label("SUNUSI", 17f, Color.WHITE, true), LinearLayout.LayoutParams(0, 45, 1f))
        top.addView(label("●  4G   ▰", 12f, 0xFFD5DDF0.toInt()))
        root.addView(top)
        val clock = label(SimpleDateFormat("h:mm", Locale.getDefault()).format(Date()), 58f)
        clock.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        clock.setPadding(4, 36, 0, 0); root.addView(clock)
        val date = label(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()), 15f, 0xFFD5DDF0.toInt())
        date.gravity = Gravity.START; date.setPadding(6, 0, 0, 22); root.addView(date)
        val search = label("⌕    Search apps", 16f)
        search.background = panel(0x44FFFFFF, 48f)
        root.addView(search, LinearLayout.LayoutParams(-1, 52).apply { bottomMargin = 22 })

        val rows = listOf(
            listOf("📞" to "Phone", "💬" to "Messages", "🌐" to "Browser", "📷" to "Camera"),
            listOf("🖼️" to "Photos", "⚙️" to "Settings", "🗓️" to "Calendar", "🎵" to "Music"),
            listOf("🧭" to "Maps", "⏰" to "Clock", "📁" to "Files", "▶️" to "YouTube")
        )
        rows.forEach { items ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            items.forEach { (emoji, name) ->
                val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
                val icon = label(emoji, 29f); icon.background = panel(0x33FFFFFF, 20f)
                cell.addView(icon, LinearLayout.LayoutParams(62, 62))
                cell.addView(label(name, 11f))
                cell.setOnClickListener { openApp(name) }
                row.addView(cell, LinearLayout.LayoutParams(0, -2, 1f))
            }
            root.addView(row)
        }
        root.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            background = panel(0x44FFFFFF, 34f); setPadding(8, 6, 8, 6)
        }
        listOf("📞" to "Phone", "🌐" to "Browser", "💬" to "Messages", "📷" to "Camera").forEach { (emoji, name) ->
            val item = label(emoji, 27f); item.setOnClickListener { openApp(name) }
            dock.addView(item, LinearLayout.LayoutParams(0, 58, 1f))
        }
        root.addView(dock, LinearLayout.LayoutParams(-1, 70))
        root.addView(label("SUNUSI iOS 27  •  Lightweight Android Launcher", 10f, 0xFFB9C4D8.toInt()))
        setContentView(root)
    }

    private fun openApp(name: String) {
        val action = when (name) {
            "Settings" -> Intent(android.provider.Settings.ACTION_SETTINGS)
            "Phone" -> Intent(Intent.ACTION_DIAL)
            "Camera" -> Intent("android.media.action.IMAGE_CAPTURE")
            "Browser" -> Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com"))
            "Messages" -> Intent(Intent.ACTION_MAIN).addCategory("android.intent.category.APP_MESSAGING")
            "Photos" -> Intent(Intent.ACTION_VIEW).setType("image/*")
            "Calendar" -> Intent(Intent.ACTION_MAIN).addCategory("android.intent.category.APP_CALENDAR")
            "Maps" -> Intent(Intent.ACTION_VIEW, android.net.Uri.parse("geo:0,0?q="))
            "Clock" -> Intent(Intent.ACTION_MAIN).addCategory("android.intent.category.APP_CLOCK")
            "Files" -> Intent(Intent.ACTION_GET_CONTENT).setType("*/*")
            "YouTube" -> Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.youtube.com"))
            else -> null
        }
        try {
            if (action != null) startActivity(action)
            else Toast.makeText(this, "$name shortcut coming soon", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            Toast.makeText(this, "$name is not available on this phone", Toast.LENGTH_SHORT).show()
        }
    }
}
